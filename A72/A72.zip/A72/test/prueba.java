/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ciclost
 */
import a72.joc.Coordenada;
import a72.joc.Tauler;
public class prueba {
    public static void main(String[] args) {
        Coordenada c1=new Coordenada();
        Tauler t1=new Tauler();
        c1.recollir();
        t1.mostrar();
    }
}
