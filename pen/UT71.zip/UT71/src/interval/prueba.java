/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interval;

/**
 *
 * @author ciclost
 */
public class prueba {
    public static void main(String[] args) {
        Interval i1=new Interval(1,5);
        Interval i2=new Interval(1,5);
        Interval i3=new Interval();
        i3.recollir();
       
    }
}
