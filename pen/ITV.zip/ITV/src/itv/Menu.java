package itv;

import util.GestorIO;
import util.Interval;

public class Menu {
    GestorIO teclat = new GestorIO();
    
    private static final String[] TITOLS= new String[]{
        "1. Alta i recepcio de vehicles",
        "2. Reclamar vehicle per a entrar al box",
        "3. Moure tots el vehicles de fase dins de un box",
        "4. Informacio del estat de un box concret",
        "5. Informacio general de tots el boxes",
        "6. Eixir del programa"
        
    };
    private static final Interval opcions=new Interval(1,6);
    
    public void menu(){
        
    }
    
    public void mostrar(){
        
    }
    public int demanarOpcio(){
        int opcio;
        boolean error=false;
        do{
        teclat.out("Introdueix una opcio entre 1 i 6 \n");
        opcio=teclat.inInt();
        if(opcio<=0||opcio>6){
        teclat.out("error introdueix un nombre entre 1 i 6 ");
        error=true;
        }
        else{
            error=false;
        }
        
        }
        while(error);
        return opcio;
        
    }
}
