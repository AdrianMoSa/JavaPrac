package itv;

public class Box {
 private FaseRevisio [] fases;
 private int id;
 private static final String[] Titol_Fases=new String[]{
 "1. Revisio inicial de elements de seguretat ",
 "2. Revisio de sistema electric ",
 "3. Revisio de emisio de fums ",
 "4. Revisio de frens i direccio"
 };
 
 /*
 public boolean estaLliure(){
     
 }
public  boolean esPrimeraFase(int){
 }
 
 public void afegir(Vehicle vehicle){
 
 }

public void passarVehiclesDeFase(){
 }
 
 public void mostrar(){
 
 }

*/
}
