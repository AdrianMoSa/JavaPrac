package itv;

public class FaseRevisio {
private Vehicle vehicle;
private String nomFase;

/*
public boolean teVehicle(){

}

public void asignar (Vehicle){

}

public void desasignar (){

}

public mostrar(){

}

public void asignarA(FaseRevisio){


}

*/
    
}
