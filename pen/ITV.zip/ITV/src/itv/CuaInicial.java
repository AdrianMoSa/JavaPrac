package itv;

import java.util.Arrays;
import util.GestorIO;

public class CuaInicial {
private Vehicle [] vehicles;
GestorIO teclat= new GestorIO();

public void CuaInicial(){
vehicles=new Vehicle[0];
}

public void afegir (Vehicle vehicle){
    vehicles=Arrays.copyOf(vehicles, vehicles.length+1);
    vehicles[vehicles.length-1]=vehicle;
}
public void traure(){
for(int i=0;i<vehicles.length;i++){
    if(vehicles[i]!=null){
        vehicles[i]=null;
        break;
    }
}
}    
public void mostrar(){
for(int i=0;i<vehicles.length;i++){
    teclat.out("Cua: "+(i+1)+": "+vehicles[i]+"\n");
}

}

    
}
