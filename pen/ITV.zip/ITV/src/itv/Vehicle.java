package itv;

import enums.TipusVehicle;
import java.util.regex.Pattern;
import util.GestorIO;

public class Vehicle {
    GestorIO teclat=new GestorIO();
    private String matricula;
    private String modelo;
    private TipusVehicle tipusVehicle;
    private static final String PATRON=("\\d{4}[A-Z]{3}");

    public Vehicle(String matricula, String modelo, TipusVehicle tipusVehicle) {
        assert Pattern.matches(PATRON, matricula);
        this.matricula = matricula;
        this.modelo = modelo;
        this.tipusVehicle = tipusVehicle;
    }
    
     public boolean teMatricula(String matricula){
         assert matricula!=null;
         return this.matricula.equals(matricula);
    }

    @Override
    public String toString() {
        return "Vehicle{matricula=" + matricula + ", modelo=" + modelo + ", tipusVehicle=" + tipusVehicle + '}';
    }

    
}
