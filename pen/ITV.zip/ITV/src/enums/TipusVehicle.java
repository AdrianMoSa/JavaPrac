package enums;

public enum TipusVehicle {

    cotxe,
    microbus,
    furgoneta,
    camio
}
