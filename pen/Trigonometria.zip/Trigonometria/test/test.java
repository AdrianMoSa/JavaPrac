/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ciclost
 */
import trigonometria.Angle;
import trigonometria.Triangle;
public class test {
    public static void main(String[] args) {
        Angle a= new Angle(89);
        Triangle t=new Triangle(2,2,2);
        System.out.println(t);
      
        
    }
}
